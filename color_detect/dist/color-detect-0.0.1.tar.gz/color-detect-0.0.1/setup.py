from setuptools import setup, find_packages

with open("README.md", "r") as f:
    long_description = f.read()

setup(
    name="color-detect", 
    version="0.0.1",
    author="Korede Bashir",
    author_email="bashirkorede@gmail.com",
    description="A mini package to work with detecting colors from images",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/bashirk/color-detect",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ]
)
